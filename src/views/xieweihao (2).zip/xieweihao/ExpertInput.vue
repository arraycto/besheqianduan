<template>
  <div class="app-container">
    <el-container>
      <el-header>
        手动添加图谱数据库
      </el-header>
      <el-container id="button_bg">
        <el-main id="button">
          <el-button>实体数据管理</el-button>
          <el-button @click="handleClick()">关系数据管理</el-button>
        </el-main>
      </el-container>
      <el-container class="mydiv1">
        <el-container>
          <div class="div1">当前实体类型:</div>
          <el-select v-model="value" placeholder="请选择">
            <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-container>
        <el-container class="mydiv2">
          <el-button type="primary" class="inRight" @click="addOneEntity()">单条添加</el-button>
          <el-button type="info" class="inRight">下载模板</el-button>
          <el-button type="info" class="inRight">导出数据</el-button>
          <el-button type="success" class="inRight">批量上传</el-button>
        </el-container>
      </el-container>
      <el-dialog title="编辑实体" :visible.sync="dialogFormVisible">
        <el-form :model="form">
          <el-form-item label="实体类型：" :label-width="formLabelWidth">
            <el-input v-model="form.object_type" autocomplete="off" :disabled="true"></el-input>
          </el-form-item>
          <el-form-item label="实体ID：" :label-width="formLabelWidth">
            <el-input v-model="form.document_id" autocomplete="off" :disabled="true"></el-input>
          </el-form-item>
          <el-form-item label="名称：" :label-width="formLabelWidth">
            <el-input v-model="form.name" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="描述：" :label-width="formLabelWidth">
            <el-input v-model="form.description" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="ICD-11：" :label-width="formLabelWidth">
            <el-input v-model="form.iCD_11" autocomplete="off"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false" type="danger">取 消</el-button>
          <el-button type="success" @click="dialogFormVisible = false" >确 定</el-button>
        </div>
      </el-dialog>

      <el-dialog title="编辑实体数据" :visible.sync="dialogFormVisible1">
        <el-form :model="form">
          <el-form-item label="实体类型：" :label-width="formLabelWidth">
            <el-input placeholder="疾病类型" size="mini"></el-input>
          </el-form-item>
          <el-form-item label="名称：" :label-width="formLabelWidth">
            <el-input placeholder="请填写文本格式数据" size="mini"></el-input>
          </el-form-item>
          <el-form-item label="描述：" :label-width="formLabelWidth">
            <el-input placeholder="请填写文本格式数据" size="mini"></el-input>
          </el-form-item>
          <el-form-item label="ICD-11：" :label-width="formLabelWidth">
            <el-input placeholder="请填写文本格式数据" size="mini"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible1 = false" type="danger">取 消</el-button>
          <el-button type="success" @click="dialogFormVisible1 = false" >确 定</el-button>
        </div>
      </el-dialog>
      <el-drawer
        title="新建关系"
        :visible.sync="drawer"
        :direction="direction"
        :before-close="handleClose"
        :v-model="form"
        size="40%">
        <div>
          <span>当前选中的起点实体：</span>
          <span>实体类型：</span>
          <span>{{form.object_type}}</span>
        </div>
        <div>
          <span>实体ID：</span>
          <span>{{form.document_id}}</span>
        </div>
        <div>
          <span>属性摘要：</span>
          <span>{{form.name}}</span>
        </div>
        <el-divider></el-divider>
        <div>
          <span>终点实体配置：</span>
          <span>类型</span>
          <span>
            <el-select v-model="value" placeholder="请选择">
              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </span>
          <el-button type="primary" round size="mini"  @click="innerDrawer = true">选择实例</el-button>
          <el-drawer
            title="请选择一个疾病类型的实例："
            :append-to-body="true"
            :before-close="handleClose"
            :visible.sync="innerDrawer">
            <div>
              <el-autocomplete
              v-model="state"
              :fetch-suggestions="querySearchAsync"
              placeholder="请输入内容"
              @select="handleSelect"
            ></el-autocomplete>
            </div>
          </el-drawer>
        </div>
        <div>
          <span>
            实体ID
          </span>
          <span></span>
        </div>
        <div>
          <span>
            属性摘要
          </span>
          <span></span>
        </div>
        <el-divider></el-divider>
        <div>
          <span>
            实体关系配置
          </span>
          <el-select v-model="relation_value" placeholder="请选择活动区域" @change="handleChange($event)">
            <el-option
              v-for="item in relation_options"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </div>
        <div style="text-align: center;height:60px;">
          <div style="text-align: center;height:40px;">
            <el-button type="primary" class="margin-top:20px;">
              提交
            </el-button>
          </div>
        </div>

      </el-drawer>
      <div class="margin">
        <el-autocomplete
        v-model="state"
        :fetch-suggestions="querySearchAsync"
        placeholder="请输入内容"
        @select="handleSelect"
      ></el-autocomplete>
        <el-button style="margin-bottom:20px;margin-left:20px;" type="primary">
          搜索
        </el-button>
      </div>
      <el-table ref="dragTable" v-loading="listLoading" :data="nowTable" :row-key="getRowKey" border fit highlight-current-row style="width: 100%">
        <el-table-column align="center" label="实例ID" width="200px">
          <template slot-scope="{row}">
            <span>{{ row.document_id }}</span>
          </template>
        </el-table-column>

        <el-table-column width="300px" label="名称">
          <template slot-scope="{row}">
            <span>{{ row.name }}</span>
          </template>
        </el-table-column>

        <el-table-column width="500px" align="center" label="描述">
          <template slot-scope="{row}">
            <span>{{ row.description }}</span>
          </template>
        </el-table-column>

        <el-table-column class-name="status-col" label="实体操作" width="100px">
          <template slot-scope="{row}">
            <span>
              <a @click="js_method(row)" style="text-decoration:underline; color: blue;">编辑实体</a>
            </span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="关系操作" min-width="180">
          <template slot-scope="{row}">
            <a @click="js_method1(row)" style="text-decoration:underline; color: blue;">新建关系</a>
            <a @click="js_method()" style="text-decoration:underline; color: blue; margin-left:10px;">查看与修改</a>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
      background
      layout="total, sizes, prev, pager, next, jumper"
      :total="list.length"
      :page-size="pagesize"
      :current-page="currentPage"
      :page-sizes="[1, 2, 5, 10]"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
    >
    </el-pagination>
    </el-container>
  </div>
</template>

<script>
import { fetchList } from '@/api/article'
import Sortable from 'sortablejs'
import axios from 'axios'

export default {
  name: 'DragTable',
  filters: {
    statusFilter(status) {
      const statusMap = {
        true: 'success',
        false: 'info'
        // false: 'danger'
      }
      return statusMap[status]
    }
  },
  data() {
    return {
      count: 1,
      list: [],
      total: '',
      listLoading: true,
      listQuery: {
        page: 1,
        limit: 10
      },
      sortable: null,
      oldList: [],
      newList: [],
      options: [],
      value: '',
      state: "",
      dialogFormVisible: false,
      dialogFormVisible1: false,
      form: {
          name: '',
          type: '',
          iCD_11: '',
          description: '',
          object_type: '',
          document_id: ''
        },
      formLabelWidth: '120px',
      drawer: false,
      direction: 'rtl',
      pagesize: 1,
      currentPage: 1,
      relation_value: '',
      relation_options: [],
      innerDrawer: false
    }
  },
  computed: {
    nowTable() {
      return (
        this.list.slice(
          (this.currentPage - 1) * this.pagesize,
          this.currentPage * this.pagesize
        ) || []
      );
    },
  },
  created() {
    // this.getList()
    this.getReference()
    this.getData()
    this.getRelationData()
  },
  methods: {
    async getList() {
      this.listLoading = true
      const { data } = await fetchList(this.listQuery)
      this.list = data.items
      console.log(this.list)// test
      // this.total = data.total
      this.listLoading = false
      this.oldList = this.list.map(v => v.id)
      this.newList = this.oldList.slice()
      this.$nextTick(() => {
        this.setSort()
      })
    },
    getReference() {
      const url = 'http://localhost:10088/FileMarks/getFileMark'
      this.listLoading = true
      axios.get(url)
        .then((response) => {
          // console.log(response)
          const { data } = response
          data.forEach((e) => {
            let document_id = e.document_id
            let document_type = e.document_type
            e.object_marks.forEach((f) => {
              let object_type = f.object_type
              f.objects.forEach((g) => {
                let item = {document_id: document_id, document_type: document_type, 
            object_type: object_type, description: '', iCD_11: '', type: '', name: ''}
                item.name = g.name
                item.iCD_11 = g.iCD_11
                item.description = g.description
                this.list.push(item)
              })
            })
          })
          this.listLoading = false
          // this.list = data
          // console.log(888888)// test
          // console.log(this.list)// test
          // this.listLoading = false
          this.oldList = this.list.map(v => v.id)
          this.newList = this.oldList.slice()
          this.$nextTick(() => {
            this.setSort()
          })
        })
    },
    getData() {
      const url = "http://localhost:10088/Entities/entity";
      axios.get(url).then((response) => {
        console.log('999999999999999999999999999999')
        console.log(response.data)
        const datas = response.data;
        for(var data in datas) {
          let a = {
            value: '',
            label: ''
          }
          a.value = datas[data].name
          a.label = datas[data].name
          this.options.push(a)
        }
        // this.labels = data;
        console.log(this.options);
      })
    },
    getRowKey(row) {
      return row.name
    },
    js_method(row) {
      console.log(row)
      this.dialogFormVisible = true
      this.form.object_type = row.object_type
      this.form.name = row.name
      this.form.iCD_11 = row.iCD_11
      this.form.description = row.description
      this.form.document_id = row.document_id
    },
    js_method1(row) {
      this.drawer = true
      this.form.object_type = row.object_type
      this.form.name = row.name
      this.form.iCD_11 = row.iCD_11
      this.form.description = row.description
      this.form.document_id = row.document_id
    },
    querySearchAsync(queryString, cb) {
      var search_data = this.list;
      console.log(queryString);
      this.results = queryString
        ? search_data.filter(this.createStateFilter(queryString))
        : search_data;
      console.log(this.results);

      const list = [];
      for (let result of this.results) {
        list.push({ value: result.title });
      }

      clearTimeout(this.timeout);
      this.timeout = setTimeout(() => {
        if (list.length !== this.list.length) {
          cb(list);
        } else {
          cb([]);
        }
      }, 3000 * Math.random());
    },
    handleSelect(item) {
      console.log(item);
      // this.list = this.results;
      // this.nowTable;
    },
    handleClose(done) {
        this.$confirm('确认关闭？')
          .then(_ => {
            done();
          })
          .catch(_ => {});
    },
    handleSizeChange: function (size) {
      this.pagesize = size;
    },
    handleCurrentChange: function (currentPage) {
      this.currentPage = currentPage;
    },
    handleClick() {
      this.$router.push({
        path: '/xieweihao/ExpertInput/RelationDataProcess',
        query: {
        }
      });
    },
    addOneEntity() {
      this.dialogFormVisible1 = true
    },
    handleChange(e) {
      this.choice = e
      let obj = {
        addedRelation: e
      }
      // this.tableData.push(obj)
    },
    getRelationData() {
      const url = "http://localhost:10088/Relations/relation";
      axios.get(url).then((response) => {
        const datas = response.data;
        for(var data in datas) {
          let a = {
            value: '药品分类-适应症-疾病',
            label: '药品分类-适应症-疾病'
          }
          a.value = datas[data].object + '-' + datas[data].relation + '-' + datas[data].subject
          a.label = datas[data].object + '-' + datas[data].relation + '-' + datas[data].subject
          this.relation_options.push(a)
        }
      });
    },
    setSort() {
      const el = this.$refs.dragTable.$el.querySelectorAll('.el-table__body-wrapper > table > tbody')[0]
      this.sortable = Sortable.create(el, {
        ghostClass: 'sortable-ghost', // Class name for the drop placeholder,
        setData: function(dataTransfer) {
          // to avoid Firefox bug
          // Detail see : https://github.com/RubaXa/Sortable/issues/1012
          dataTransfer.setData('Text', '')
        },
        onEnd: evt => {
          const targetRow = this.list.splice(evt.oldIndex, 1)[0]
          this.list.splice(evt.newIndex, 0, targetRow)

          // for show the changes, you can delete in you code
          const tempIndex = this.newList.splice(evt.oldIndex, 1)[0]
          this.newList.splice(evt.newIndex, 0, tempIndex)
        },
      })
    }
  }
}
</script>

<style>
.sortable-ghost{
  opacity: .8;
  color: #fff!important;
  background: #42b983!important;
}
</style>

<style scoped>
.icon-star{
  margin-right:2px;
}
.drag-handler{
  width: 20px;
  height: 20px;
  cursor: pointer;
}
.show-d{
  margin-top: 15px;
}
.el-header, .el-footer {
    background-color: #B3C0D1;
    color: #333;
    text-align: center;
    line-height: 60px;
    font-weight: bold;
    font-size: 30px;
  }
.mydiv1 {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}
.mydiv2 {
  display: flex;
  flex-direction: row;
}
.inRight {
  margin-left: auto;
}
#button {
  text-align: center;
  margin: auto;
}
#button_bg {
  background-color: #B3C0D1;
}

.div1 {
  width: 150px;
  line-height: 40px;
  height: 40px;
}

.margin {
  margin-top: 10px;
}

</style>
